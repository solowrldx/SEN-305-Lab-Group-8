# Frontend

The user interface is rendered with Django Templates from `backend/core/templates/core/`. Styling is served through Django's static files system from `backend/core/static/core/css/styles.css`. This keeps the practical's frontend simple and aligned with the required Model-View-Template architecture.
