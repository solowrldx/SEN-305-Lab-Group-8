# Infrastructure and database notes

SQLite is the default database for the initial practical and requires no separate server. The optional MySQL extension is configured through environment variables (`DB_ENGINE=mysql`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT`). See the repository README for database creation and migration commands. Never commit `.env` or real credentials.
