# Enterprise Service Request and Maintenance Platform

A beginner-friendly Django 5.2 practical project for VUA-SEN305. It demonstrates Django's Model-View-Template pattern, shared templates, static CSS, model validation, Django Admin, migrations, querysets, indexes, synthetic data, tests, and SQLite-first/MySQL-ready configuration.

## 1. What the project does

The platform introduces a simple workflow for submitting, triaging, assigning, and resolving maintenance/service requests. The Lab Session 2 pages are Home, About, Contact, and Workflow. The data-model extension adds service categories and service requests with status, priority, due dates, resolution details, and overdue handling.

## 2. Folder structure

- `backend/config/`: Django project settings and root URL configuration.
- `backend/core/`: the single Django application, models, views, admin, tests, templates, CSS, migrations, and management commands.
- `frontend/`: notes about Django-rendered frontend templates.
- `infrastructure/`: SQLite and MySQL setup notes.
- `docs/PROJECT_NOTES.md`: practical examples and explanations.
- `.env.example`: safe environment-variable template.

## 3. Prerequisites

- Windows 10/11
- Python 3.12
- VS Code (recommended)
- Git (for version control)
- MySQL Server only if completing the optional database extension

## 4. Open in VS Code

Extract `sen305-service-platform.zip`, open VS Code, choose **File → Open Folder**, and select the extracted `sen305-service-platform` folder. Open **Terminal → New Terminal**. Commands below assume PowerShell and that the terminal is at the repository root.

## 5. Create and activate a virtual environment (Windows PowerShell)

```powershell
cd path\to\sen305-service-platform
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation for this terminal, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 6. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r backend\requirements.txt
```

The project uses Django 5.2. Python 3.12 is the target interpreter. `mysqlclient` is included for the optional MySQL extension; if its installation requires local build tools on your Windows machine, you can still use SQLite without configuring MySQL. The MySQL driver is not imported unless MySQL is selected.

## 7. Run migrations

```powershell
cd backend
python manage.py migrate
```

SQLite is selected by default. The database file is created at `backend\db.sqlite3` on first migration.

## 8. Create a superuser

```powershell
python manage.py createsuperuser
```

Follow the prompts to create your own local admin account.

## 9. Start the development server

```powershell
python manage.py runserver
```

Open `http://127.0.0.1:8000/` in your browser.

## 10. Django Admin

Visit `http://127.0.0.1:8000/admin/` and sign in with the superuser credentials you created. Both ServiceCategory and ServiceRequest are registered.

## 11. Inspect migration 0002

From the `backend` directory:

```powershell
python manage.py sqlmigrate core 0002
python manage.py migrate
```

Migration `0002_service_request_due_and_resolution.py` depends on `0001_initial.py`, adds `due_at`, adds `resolution_summary`, and creates the named composite index. The original initial migration is not modified.

## 12. Run automated tests

```powershell
python manage.py test
```

The tests cover model validation, nullable due dates, due-date filtering, overdue logic, page responses, workflow rendering, and unknown URLs.

## 13. Generate synthetic data

```powershell
python manage.py seed_demo
```

The command creates two categories and at least ten fictional requests across multiple statuses, priorities, and due dates. It is safe to run repeatedly because the command clears only records carrying its own `DEMO-` title prefix before reseeding.

## 14. Inspect SQL and query plans

```powershell
python manage.py inspect_requests
```

The command filters a selected category for OPEN or ASSIGNED requests, orders by priority and creation date, and prints the generated SQL and database query plan. The query plan is database-dependent. A small SQLite demo dataset may produce a table scan rather than use an index; do not claim index usage unless the plan explicitly shows it. The composite index is on `(status, due_at)` and supports queries filtering on those columns, but it is not necessarily optimal for every category/priority query.

## 15. Configure MySQL (optional extension)

First create a database and a dedicated database user in MySQL. Example SQL (replace the placeholder password with your own secure local password):

```sql
CREATE DATABASE sen305_service_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'sen305_user'@'localhost' IDENTIFIED BY 'REPLACE_WITH_A_SECURE_PASSWORD';
GRANT ALL PRIVILEGES ON sen305_service_platform.* TO 'sen305_user'@'localhost';
FLUSH PRIVILEGES;
```

At the repository root, copy `.env.example` to `.env` and edit the values. Do not commit `.env`.

```powershell
Copy-Item .env.example .env
```

Set these values in `.env`:

```dotenv
DB_ENGINE=mysql
DB_NAME=sen305_service_platform
DB_USER=sen305_user
DB_PASSWORD=your-local-password
DB_HOST=127.0.0.1
DB_PORT=3306
```

Install requirements (including `mysqlclient`), ensure the MySQL server is running, then from `backend` run:

```powershell
python manage.py migrate
```

To return to SQLite, set `DB_ENGINE=sqlite` or remove that setting. The application defaults to SQLite if no `.env` database setting is supplied. Environment variables are read directly; no secrets are stored in source code.

## 16. Test the custom 404 page

Django normally serves the custom project-level `404.html` only when `DEBUG=False`. For a local test, temporarily set `DEBUG=False` in `.env` (or your process environment), ensure `ALLOWED_HOSTS` includes `127.0.0.1,localhost`, restart the server, and visit a URL that does not exist, such as `http://127.0.0.1:8000/this-page-does-not-exist/`. Restore `DEBUG=True` for normal local development. Do not leave debug disabled during ordinary practical work.

## 17. Git workflow

A suggested feature branch is `feature/django-mvt-foundation`.

```powershell
git init
git switch -c feature/django-mvt-foundation
git status
git add .
git commit -m "Build SEN305 Django service platform foundation"
git remote add origin <your-repository-url>
git push -u origin feature/django-mvt-foundation
```

Replace `<your-repository-url>` with the URL of a repository you create. No remote URL is assumed or included.

## 18. Verification status for this delivered archive

The project source files were checked for Python syntax during packaging. Django is not installed in the file-generation environment, so `manage.py check`, `makemigrations --check --dry-run`, `sqlmigrate`, and Django's automated test suite were **not executed here**. Run the commands above after installing dependencies on your Windows Python 3.12 environment. The migration files are included and migration consistency should be confirmed with `makemigrations --check --dry-run`.
