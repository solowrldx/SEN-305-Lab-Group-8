# Project Notes — VUA-SEN305

## Model validation examples

Validation is implemented in `ServiceRequest.clean()`, so it is model-level rather than dependent on Django Admin. Django does not automatically call `full_clean()` on every `save()`, therefore callers that need validation should call it explicitly.

Invalid resolved request:

```python
from django.core.exceptions import ValidationError
from core.models import ServiceCategory, ServiceRequest

category = ServiceCategory.objects.get(name="Facilities")
invalid_request = ServiceRequest(
    category=category,
    title="DEMO-Invalid resolution",
    description="Example only",
    status=ServiceRequest.Status.RESOLVED,
)
try:
    invalid_request.full_clean()
except ValidationError as error:
    print(error.message_dict)  # resolved_at and resolution_summary errors
```

Valid resolved request:

```python
from django.utils import timezone

valid_request = ServiceRequest(
    category=category,
    title="DEMO-Valid resolution",
    description="Example only",
    status=ServiceRequest.Status.RESOLVED,
    resolved_at=timezone.now(),
    resolution_summary="The issue was repaired and tested.",
)
valid_request.full_clean()
valid_request.save()
```

## Due date queries

Nullable due dates are supported. Requests due before a chosen time can be retrieved with:

```python
from django.utils import timezone
from core.models import ServiceRequest

chosen_time = timezone.now()
due_before_time = ServiceRequest.objects.filter(due_at__lt=chosen_time)
```

To include only active requests (and exclude RESOLVED/CLOSED):

```python
active_overdue = ServiceRequest.objects.filter(
    status__in=["OPEN", "ASSIGNED"],
    due_at__lt=chosen_time,
    due_at__isnull=False,
)
```

The `is_overdue` model property applies the same active-status rule to an individual object.

## Admin overdue filtering

The custom `OverdueListFilter` in `core/admin.py` adds Overdue and Not overdue choices. Overdue means status is OPEN or ASSIGNED and `due_at` is earlier than the current timezone-aware time. Resolved and closed requests are excluded even when their due date is in the past. Status, priority, and category are separate built-in list filters.

## Index explanation

Migration `0002_service_request_due_and_resolution.py` adds the named composite index `core_status_due_idx` over `(status, due_at)`. It can assist database queries that filter by status and due date, such as active overdue queries. The index is not a promise that every query uses it. Database optimizers consider table size, selectivity, ordering, and cost. For a tiny synthetic SQLite dataset, a table scan may be cheaper. Inspect the actual plan with `queryset.explain()`.

## Query plan demonstration

Run:

```powershell
python manage.py seed_demo
python manage.py inspect_requests
```

The management command filters one category, selects OPEN or ASSIGNED requests, orders by priority and creation time, then prints `queryset.query` and `queryset.explain()`. Change category with:

```powershell
python manage.py inspect_requests --category "ICT Support"
```

The SQL and query plan depend on the active database backend and its optimizer. Describe what your own output says; do not claim the index was used unless the plan explicitly reports it.
