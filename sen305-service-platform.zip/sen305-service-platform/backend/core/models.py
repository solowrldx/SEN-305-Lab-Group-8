from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class ServiceCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "service categories"

    def __str__(self):
        return self.name


class ServiceRequest(models.Model):
    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        ASSIGNED = "ASSIGNED", "Assigned"
        RESOLVED = "RESOLVED", "Resolved"
        CLOSED = "CLOSED", "Closed"

    class Priority(models.TextChoices):
        LOW = "LOW", "Low"
        MEDIUM = "MEDIUM", "Medium"
        HIGH = "HIGH", "High"
        URGENT = "URGENT", "Urgent"

    category = models.ForeignKey(
        ServiceCategory,
        on_delete=models.PROTECT,
        related_name="requests",
    )
    title = models.CharField(max_length=160)
    description = models.TextField()
    status = models.CharField(
        max_length=12, choices=Status.choices, default=Status.OPEN
    )
    priority = models.CharField(
        max_length=10, choices=Priority.choices, default=Priority.MEDIUM
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status", "due_at"], name="core_status_due_idx"),
        ]

    due_at = models.DateTimeField(null=True, blank=True)
    resolution_summary = models.TextField(blank=True)

    def clean(self):
        super().clean()
        if self.status in {self.Status.RESOLVED, self.Status.CLOSED}:
            errors = {}
            if not self.resolved_at:
                errors["resolved_at"] = (
                    "A resolved or closed request must have a resolution date/time."
                )
            if not self.resolution_summary.strip():
                errors["resolution_summary"] = (
                    "A resolved or closed request must include a resolution summary."
                )
            if errors:
                raise ValidationError(errors)

    @property
    def is_overdue(self):
        return (
            self.status in {self.Status.OPEN, self.Status.ASSIGNED}
            and self.due_at is not None
            and self.due_at < timezone.now()
        )

    def __str__(self):
        return f"{self.title} ({self.get_status_display()})"
