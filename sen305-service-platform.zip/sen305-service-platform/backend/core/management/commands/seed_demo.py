from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from core.models import ServiceCategory, ServiceRequest


class Command(BaseCommand):
    help = "Create fictional service categories and at least ten demonstration requests."

    def handle(self, *args, **options):
        # Re-running the command replaces only this command's own demo requests.
        ServiceRequest.objects.filter(title__startswith="DEMO-").delete()
        facilities, _ = ServiceCategory.objects.get_or_create(
            name="Facilities",
            defaults={"description": "Building and utility maintenance."},
        )
        ict, _ = ServiceCategory.objects.get_or_create(
            name="ICT Support",
            defaults={"description": "Computers, network, and classroom technology."},
        )

        now = timezone.now()
        examples = [
            ("Air conditioner inspection", facilities, "OPEN", "HIGH", -2),
            ("Library light replacement", facilities, "ASSIGNED", "MEDIUM", 2),
            ("Classroom desk repair", facilities, "OPEN", "LOW", 4),
            ("Water dispenser check", facilities, "RESOLVED", "MEDIUM", -1),
            ("Door lock maintenance", facilities, "CLOSED", "HIGH", -3),
            ("Wi-Fi access point check", ict, "OPEN", "URGENT", -1),
            ("Projector display issue", ict, "ASSIGNED", "HIGH", 1),
            ("Printer connection support", ict, "OPEN", "MEDIUM", 3),
            ("Staff workstation setup", ict, "RESOLVED", "LOW", -2),
            ("Lecture room network test", ict, "ASSIGNED", "MEDIUM", 5),
            ("Computer lab login issue", ict, "CLOSED", "URGENT", -4),
            ("Meeting room display setup", facilities, "OPEN", "LOW", 6),
        ]
        for number, (title, category, status, priority, due_offset) in enumerate(examples, 1):
            resolved = status in {"RESOLVED", "CLOSED"}
            ServiceRequest.objects.create(
                category=category,
                title=f"DEMO-{number:02d} {title}",
                description="Fictional data generated for the VUA-SEN305 practical.",
                status=status,
                priority=priority,
                due_at=now + timedelta(days=due_offset),
                resolved_at=(now - timedelta(hours=2)) if resolved else None,
                resolution_summary="Fictional work completed and checked." if resolved else "",
            )
        self.stdout.write(self.style.SUCCESS("Created 12 fictional demo service requests."))
