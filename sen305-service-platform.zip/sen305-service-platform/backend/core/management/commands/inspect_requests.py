from django.core.management.base import BaseCommand
from django.db.models import Q

from core.models import ServiceCategory, ServiceRequest


class Command(BaseCommand):
    help = "Print a filtered queryset's SQL and database query plan."

    def add_arguments(self, parser):
        parser.add_argument("--category", default="Facilities")

    def handle(self, *args, **options):
        category_name = options["category"]
        category = ServiceCategory.objects.filter(name=category_name).first()
        if category is None:
            self.stderr.write(
                self.style.ERROR(
                    f"Category '{category_name}' not found. Run 'python manage.py seed_demo' first."
                )
            )
            return

        queryset = (
            ServiceRequest.objects.filter(category=category)
            .filter(Q(status=ServiceRequest.Status.OPEN) | Q(status=ServiceRequest.Status.ASSIGNED))
            .order_by("priority", "created_at")
        )
        self.stdout.write("Generated SQL:")
        self.stdout.write(str(queryset.query))
        self.stdout.write("\nDatabase query plan:")
        self.stdout.write(queryset.explain())
        self.stdout.write(
            "\nNote: inspect the plan above. A table scan can be reasonable for a small "
            "synthetic dataset; the presence of an index does not guarantee its selection."
        )
        self.stdout.write(f"\nMatching rows: {queryset.count()}")
