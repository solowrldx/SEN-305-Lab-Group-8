from django.shortcuts import render


def home(request):
    return render(request, "core/home.html")


def about(request):
    roles = [
        "Service requester",
        "Service desk administrator",
        "Technician",
        "Platform administrator",
    ]
    return render(request, "core/about.html", {"roles": roles})


def contact(request):
    context = {
        "department_name": "Facilities and ICT Service Desk",
        "email": "service.desk@example.edu",
        "office_hours": "Monday–Friday, 9:00 AM–4:00 PM",
    }
    return render(request, "core/contact.html", context)


def workflow(request):
    stages = [
        "Request submitted",
        "Request triaged",
        "Technician assigned",
        "Request resolved",
    ]
    return render(request, "core/workflow.html", {"stages": stages})


def custom_404(request, exception):
    return render(request, "404.html", status=404)
