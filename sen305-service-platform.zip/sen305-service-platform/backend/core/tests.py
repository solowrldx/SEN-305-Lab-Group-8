from datetime import timedelta

from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import ServiceCategory, ServiceRequest


class ServiceRequestModelTests(TestCase):
    def setUp(self):
        self.category = ServiceCategory.objects.create(name="Facilities")

    def make_request(self, **kwargs):
        defaults = {
            "category": self.category,
            "title": "DEMO-Request",
            "description": "A fictional test request.",
        }
        defaults.update(kwargs)
        return ServiceRequest(**defaults)

    def test_due_date_can_be_null(self):
        request = self.make_request(due_at=None)
        request.full_clean()
        request.save()
        self.assertIsNone(request.due_at)

    def test_resolved_request_requires_resolved_at(self):
        request = self.make_request(
            status=ServiceRequest.Status.RESOLVED,
            resolution_summary="Completed successfully.",
        )
        with self.assertRaises(ValidationError) as context:
            request.full_clean()
        self.assertIn("resolved_at", context.exception.message_dict)

    def test_resolved_request_requires_summary(self):
        request = self.make_request(
            status=ServiceRequest.Status.RESOLVED,
            resolved_at=timezone.now(),
        )
        with self.assertRaises(ValidationError) as context:
            request.full_clean()
        self.assertIn("resolution_summary", context.exception.message_dict)

    def test_closed_request_requires_both_fields(self):
        request = self.make_request(status=ServiceRequest.Status.CLOSED)
        with self.assertRaises(ValidationError) as context:
            request.full_clean()
        self.assertIn("resolved_at", context.exception.message_dict)
        self.assertIn("resolution_summary", context.exception.message_dict)

    def test_valid_resolved_request_passes_full_clean(self):
        request = self.make_request(
            status=ServiceRequest.Status.RESOLVED,
            resolved_at=timezone.now(),
            resolution_summary="The fault was repaired and tested.",
        )
        request.full_clean()
        request.save()
        self.assertEqual(request.status, ServiceRequest.Status.RESOLVED)

    def test_due_date_filtering(self):
        past = timezone.now() - timedelta(days=1)
        future = timezone.now() + timedelta(days=1)
        ServiceRequest.objects.create(
            category=self.category, title="DEMO-Past", description="Past due", due_at=past
        )
        ServiceRequest.objects.create(
            category=self.category, title="DEMO-Future", description="Future due", due_at=future
        )
        found = ServiceRequest.objects.filter(due_at__lt=timezone.now())
        self.assertEqual(list(found.values_list("title", flat=True)), ["DEMO-Past"])

    def test_overdue_property_excludes_resolved_and_closed(self):
        past = timezone.now() - timedelta(hours=1)
        open_request = self.make_request(due_at=past)
        resolved_request = self.make_request(
            status=ServiceRequest.Status.RESOLVED,
            resolved_at=timezone.now(),
            resolution_summary="Resolved.",
            due_at=past,
        )
        closed_request = self.make_request(
            status=ServiceRequest.Status.CLOSED,
            resolved_at=timezone.now(),
            resolution_summary="Closed.",
            due_at=past,
        )
        self.assertTrue(open_request.is_overdue)
        self.assertFalse(resolved_request.is_overdue)
        self.assertFalse(closed_request.is_overdue)


class StaticPageTests(TestCase):
    def test_home_page(self):
        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 200)

    def test_about_page(self):
        response = self.client.get(reverse("about"))
        self.assertEqual(response.status_code, 200)

    def test_contact_page(self):
        response = self.client.get(reverse("contact"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Facilities and ICT Service Desk")
        self.assertContains(response, "service.desk@example.edu")

    def test_workflow_page_displays_all_stages(self):
        response = self.client.get(reverse("workflow"))
        self.assertEqual(response.status_code, 200)
        for stage in [
            "Request submitted",
            "Request triaged",
            "Technician assigned",
            "Request resolved",
        ]:
            self.assertContains(response, stage)

    def test_unknown_url_returns_404(self):
        response = self.client.get("/not-a-real-page/")
        self.assertEqual(response.status_code, 404)
