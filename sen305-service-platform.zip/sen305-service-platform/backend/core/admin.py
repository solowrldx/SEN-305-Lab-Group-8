from django.contrib import admin
from django.db.models import Q
from django.utils import timezone

from .models import ServiceCategory, ServiceRequest


@admin.register(ServiceCategory)
class ServiceCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at")
    search_fields = ("name", "description")
    ordering = ("name",)
    readonly_fields = ("created_at",)


class OverdueListFilter(admin.SimpleListFilter):
    title = "overdue state"
    parameter_name = "overdue"

    def lookups(self, request, model_admin):
        return (("yes", "Overdue"), ("no", "Not overdue"))

    def queryset(self, request, queryset):
        now = timezone.now()
        overdue = Q(
            status__in=[ServiceRequest.Status.OPEN, ServiceRequest.Status.ASSIGNED],
            due_at__lt=now,
            due_at__isnull=False,
        )
        if self.value() == "yes":
            return queryset.filter(overdue)
        if self.value() == "no":
            return queryset.exclude(overdue)
        return queryset


@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = (
        "title", "category", "status", "priority", "due_at",
        "resolved_at", "created_at", "is_overdue",
    )
    list_filter = ("status", "priority", "category", OverdueListFilter)
    search_fields = ("title", "description", "resolution_summary")
    ordering = ("-created_at",)
    readonly_fields = ("created_at", "updated_at")
    list_select_related = ("category",)
